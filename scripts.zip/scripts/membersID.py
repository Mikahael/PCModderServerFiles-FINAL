#allAdmins=False   #leave this always false #do not change list order or major errors will come #'pb-IF4mVWkIXQ=='#use my id to give me owner pls
mods = ['pb-JiNJARBaXEFBVF9HFkNXXF1EF0ZaRlZE', 'pb-', 'pb-IF4gVUg9NA==', 'pb-IF4JVU0ANg==', 'pb-IF5RUhYgUw==']
vips = ['pb-IF4MVWhbIQ==', 'pb-IF43VXRdDA==', 'pb-IF4VUhUjLQ==', 'pb-IF4mVUwhXQ==', 'pb-IF4qVVRfNg==', 'pb-IF4TVXM4VQ==']
nooby = ['pb-JiNJARBbVEpIXFtJFkJQUFJGFUldRVZA']
members = ['pb-IF43VXRdDA==', 'pb-IF4sUhk4JA==']
owners = ['pb-IF4mVWkIXQ==', 'pb-IF42UhkbEA==', 'pb-IF4tUhczUQ==']
whitelist = ['pb-IF5UVUobMw==', 'pb-IF42UhkbEA==', 'pb-IF4mVWkIXQ==', 'pb-IF42UhkbEA==', 'pb-IF4mVWkIXQ==', 'pb-IF42UhkbEA==', 'pb-IF5RVUMzDw==', 'pb-IF4gVUg9NA==']
muted = ['pb-JiNJARBbVEpIXFtJFkJQUFJGFUldRVZA']
rejected = []
sparkEffect = []
splinterEffect = []
slimeEffect = []
metalEffect = []
smokeEffect = []
iceEffect = []
colorEffect = []
lightEffect = []
glowEffect = []
crownTag = ['pb-IF4wVVcnDw==', 'pb-IF4HUmQjJA==', 'pb-IF5RVUMzDw==']
dragonTag = ['pb-IF4HUmQjJA==', 'pb-IF5VVUc7KQ==', 'pb-IF4eVXA8Mw==', 'pb-IF41UmckAw==', 'pb-IF4gUhgBDg==', 'pb-IF4zUmMcEw==']
helmetTag = ['pb-IF5WVVImLA==', 'pb-IF5WVVAbNw==']
bombTag = ['pb-IF4JVUshFQ==', 'pb-IF4wVVcnDw==', 'pb-IF4mUhkEVQ==']

#Special roles players can take - 

tripleMan = []
iceMan = []
impactMan = []
invMan = []
radiusMan = []
morLife = []
spazBombMan = []
glueMan = []
speedMan = []
bombMan = []
#special trail that follow you by PC
sparktrail = []
slimetrail = []
firetrail = []
woodtrail = []

mod2 = []
vip2=[]
#mod and vip without nametag

#DO NOT ADD ANY MORE ROLES OR SADLY ERROR WILL COME. THANK YOU ALSO DONT CHANGE ORDER OF THE LIST




# pb-JiNJARBaXEFBVF9HFkNXXF1EF0ZaRlZE  id of Mr.Smoothy 
# pb-IF4mVWkIXQ== id of Avarohana/PCModder
# dont remove leeme enjoy too in your server :P 
#atleast VIP ???   :(
#   NO ????   you dont deserve help ... 
#https://github.com/imayushsaini/Bombsquad-Mr.Smoothy-Admin-Powerup-Server



