#allAdmins=False   #leave this always false #do not change list order or major errors will come #'pb-IF4mVWkIXQ=='#use my id to give me owner pls
mods = ['pb-IF4gVUg9NA==']
vips = ['pb-IF49Uk0kIQ==']
nooby = []
members = []
owners = ['pb-IF4wVVERHQ==', 'pb-IF48UngoNA==', 'pb-IF4QVBY4XQ==']
whitelist = ['pb-IF48UngoNA==']
muted = []
rejected = []
sparkEffect = []
splinterEffect = []
slimeEffect = []
metalEffect = []
smokeEffect = []
iceEffect = []
colorEffect = []
lightEffect = []
glowEffect = []
crownTag = []
dragonTag = []
helmetTag = []
bombTag = []

#Special roles players can take - 

tripleMan = []
iceMan = []
impactMan = []
invMan = []
radiusMan = []
morLife = []
spazBombMan = []
glueMan = []
speedMan = []
bombMan = []
#special trail that follow you by PC
sparktrail = []
slimetrail = []
firetrail = []
woodtrail = []

mod2 = []
vip2=[]
verify = ['pb-IF49Uk0kIQ==', 'pb-IF4vUngOBw==', 'pb-IF4gVUg9NA==', 'pb-IF48UngoNA==']
mute5=['pb-IF48UngoNA==']
#mod and vip without nametag

#DO NOT ADD ANY MORE ROLES OR SADLY ERROR WILL COME. THANK YOU ALSO DONT CHANGE ORDER OF THE LIST




# pb-JiNJARBaXEFBVF9HFkNXXF1EF0ZaRlZE  id of Mr.Smoothy 
# 'pb-IF48UngoNA==' id of Avarohana/PCModder
# dont remove leeme enjoy too in your server :P 
#atleast VIP ???   :(
#   NO ????   you dont deserve help ... 
#https://github.com/imayushsaini/Bombsquad-Mr.Smoothy-Admin-Powerup-Server

#as the license states, all rights reserved to Avarohana/Mikahael/PCModder. (All are the same people)



