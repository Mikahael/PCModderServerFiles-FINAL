allAdmins=False   #leave this always false #do not change list order or major errors will come #'pb-IF4mVWkIXQ=='#use my id to give me owner pls
mods = ['pb-JiNJARBaXEFBVF9HFkNXXF1EF0ZaRlZE', 'pb-', 'pb-IF4gVUg9NA==']
vips = ['pb-IF4qVWQBEQ==', 'pb-IF40VEQuIA==', 'pb-IF4gVVpfKw==']
nooby = []
members = ['pb-IF4rVUskFw==', 'pb-IF4MVXo5Cw==', 'pb-IF4BVVEPNg==']
owners = ['pb-IF5WNkla', 'pb-JjBJIRpaXUFDW19JEUVQ', 'pb-IF4wVVcnDw==', 'pb-JiNJARFfVkpGVVlCFEdYXV1DEUdZQ1RL', 'pb-IF4lVFYyKQ==', 'pb-IF4mVWkIXQ==', 'pb-IF4mVWkIXQ==', 'pb-JiNJARBaVEVHXVZEF0BTXVVHEkleRFFB']
whitelist = ['pb-JjBJIRpaXUFDW19JEUVQ','pb-IF4lVFYyKQ==', 'pb-IF4lVVYmPQ==', 'pb-IF4mVWkIXQ==','pb-JiNJARFfXEtHW15BE0RWU1JDFUJXTlBD']
muted = ['pb-IF4dVVYKFA==', 'pb-IF4CVXYCPQ==', 'pb-IF4MVXo5Cw==', 'pb-IF4wVVcnDw==', 'pb-IF4nVFMqPA==']
rejected = []
sparkEffect = []
splinterEffect = []
slimeEffect = []
metalEffect = []
smokeEffect = []
iceEffect = []
colorEffect = []
lightEffect = []
glowEffect = []
crownTag = ['pb-IF4lVVYmPQ==', 'pb-IF4dVFlYMg==', 'pb-JiNJARBaVEVHXVZEF0BTXVVHEkleRFFB']
dragonTag = ['pb-IF4mDXcv']
helmetTag = []
bombTag = []

#Special roles players can take - 

tripleMan = []
iceMan = []
impactMan = []
invMan = []
radiusMan = []
morLife = []
spazBombMan = []
glueMan = []
speedMan = []
bombMan = []
#special trail that follow you by PC
sparktrail = []
slimetrail = []
firetrail = []
woodtrail = []

mod2 = []
vip2=[]
#mod and vip without nametag

#DO NOT ADD ANY MORE ROLES OR SADLY ERROR WILL COME. THANK YOU ALSO DONT CHANGE ORDER OF THE LIST




# pb-JiNJARBaXEFBVF9HFkNXXF1EF0ZaRlZE  id of Mr.Smoothy 
# pb-IF4mVWkIXQ== id of Avarohana/PCModder
# dont remove leeme enjoy too in your server :P 
#atleast VIP ???   :(
#   NO ????   you dont deserve help ... 
#https://github.com/imayushsaini/Bombsquad-Mr.Smoothy-Admin-Powerup-Server



