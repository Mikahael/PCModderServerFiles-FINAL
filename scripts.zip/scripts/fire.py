#never change the order of this list, if you want to add more settings go all the way down and add||NEVER
whitelist = False
#DO NOT CHANGE ORDER OF SETTINGS DO NOT ADD OR DELETE POWERUPS MAJOR ERRROR---> ADMIN SYS USELESS AND DOWN UNLESS YOU FIX WHICH IS HARD
powerupName = True

lightning = True#small light node emits when pwp touched

powerupShield = False
#some wicked lighting for you pwp
discoLights = False

shieldBomb = False

spamProtection = True

newName = False
#ahh press one of the control buttons when enabled
colory = False

randomChar = False#ahh press one of the control buttons when enabled

animate = False#basically the color animation on name on bomb etc

powerupTimer = True#small timer indicates when pwp refreshed
#never change the order of this list, if you want to add more settings go all the way down and add
bombName = True

bombTimer = True#small timer indicates when bomb kaboom
#new model for bomb
bombModel = False
#DO NOT CHANGE ORDER OF SETTINGS DO NOT ADD OR DELETE POWERUPS MAJOR ERRROR---> ADMIN SYS USELESS AND DOWN UNLESS YOU FIX WHICH IS HARD
nameP = False#put popup text on names of pwp when touched. only works in the spazpc

hp = False#the hp tag, thanks to froshlee14 for dis

tag = False#a fresh tag given to all spazes

powSet = True #no pwp on map
#disable or enable pwp if false pwp will not be accepted
pwp = True
#never change the order of this list, if you want to add more settings go all the way down and add
atomModel = True #never turn off
#if you want pc powerups enable this
modded_powerups = False
#DO NOT CHANGE ORDER OF SETTINGS DO NOT ADD OR DELETE POWERUPS MAJOR ERRROR---> ADMIN SYS USELESS AND DOWN UNLESS YOU FIX WHICH IS HARD
powerup_dist = (('tripleBombs', 0), 
                ('iceBombs', 0), 
                ('punch', 0),
                ('impactBombs', 0), 
                ('landMines', 0), 
                ('stickyBombs', 0),
                ('tnt',0),
                ('strongICE',0),
                ('speedBoots',0),
                ('champ',0),
                ('troll',0),
                ('character',0),
                ('invisible',2),
                ('shield', 0), 
                ('health', 0),
                ('sloMo',0), 
                ('invincible',0),#warning no timer on dis guy. might be best to disable
                ('curseBomb',2),
                ('hybridBomb',2),
                ('iceImpact',2),
                ('blastBomb',2),
                ('boomBomb',2),
                ('revengeBomb',2),
                ('multiBomb',2),
                ('tntExplode',2),
                ("antiGrav", 2),
                ('headache', 2),
                ('radius', 2),
                ('night',0),
                ('atomBomb',2),
                ('portal',2),
                ('jumpFly',2),
                ('snoball', 2),
                ('blackHole',2),
                ('touchMe',2),
                ('impactShower',2),
                ('curseShower',2),
                ('superStar',2),
                ('knockBomb',2),
                ('weedbomb',2),
                ('frozenBomb',2),
                ('iceMine',2),
                ('teleBomb',2),
                ('gluebomb',2),
                ('spazBomb',2),
                ('portalBomb',2),
                ('cursyBomb',2),
                ('volcano',2),
                ('martyrdom',0),
                ('blaster',0),
                ('knock', 0),
                ('bubble',2),
                ('mag',2),
                ('bomber',2),
                ('stickyIce',2),
                ('botSpawner',2),
                ('plsTouchMe',2),
                ('shockWave',2),
                ('blast',2),
                ('fireBomb',0),
                ('epicMine',0),
                ('powerup',0),
                ('blastBot',2),
                ('beachBall',2),
                ('pirateBot',2),
                ('spikeBomb',2),
                ('mix',0),
                ('map',2),
                ('spunch',2),
                ('characterPicker',2),
                ('colorPicker',2),
                ('flyer',2),
                ('curse', 0))
                
regular_dist = (('tripleBombs', 3), 
                ('iceBombs', 3), 
                ('punch', 3),
                ('impactBombs', 3), 
                ('landMines', 2), 
                ('stickyBombs', 3),
                ('tnt',2),
                ('strongICE',3),
                ('speedBoots',2),
                ('champ',1),
                ('troll',2),
                ('character',4),
                ('invisible',2),
                ('shield', 2), 
                ('health', 1),
                ('sloMo',4), 
                ('invincible',0),#warning no timer on dis guy. might be best to disable
                ('curseBomb',0),
                ('hybridBomb',2),
                ('iceImpact',0),
                ('blastBomb',0),
                ('boomBomb',0),
                ('revengeBomb',0),
                ('multiBomb',2),
                ('tntExplode',2),
                ("antiGrav", 0),
                ('headache', 0),
                ('radius', 0),
                ('night',2),
                ('atomBomb',0),
                ('portal',0),
                ('jumpFly',0),
                ('snoball', 0),
                ('blackHole',0),
                ('touchMe',0),
                ('impactShower',0),
                ('superStar',2),
                ('knockBomb',0),
                ('weedbomb',0),
                ('frozenBomb',0),
                ('iceMine',2),
                ('teleBomb',0),
                ('gluebomb',0),
                ('spazBomb',2),
                ('portalBomb',0),
                ('cursyBomb',0),
                ('volcano',0),
                ('martyrdom',2),
                ('blaster',0),
                ('knock', 2),
                ('bubble',0),
                ('mag',0),
                ('bomber',0),
                ('stickyIce',0),
                ('botSpawner',0),
                ('plsTouchMe',0),
                ('shockWave',0),
                ('blast',2),
                ('fireBomb',0),
                ('epicMine',0),
                ('powerup',0),
                ('blastBot',0),
                ('beachBall',2),
                ('spikeBomb',0),
                ('pirateBot',0),
                ('mix',2),
                ('curseShower',0),
                ('map',0),
                ('spunch',0),
                ('characterPicker',0),
                ('colorPicker',0),
                ('flyer',2),
                ('curse', 1))

#basically enables "Night" Mode(do not change order of any or major error will come)
night = False
#creates a loong flash for pwp OP
flash = False

#pwp floats up a little   
powExplo = False
##DO NOT CHANGE ORDER OF SETTINGS DO NOT ADD OR DELETE POWERUPS MAJOR ERRROR---> ADMIN SYS USELESS AND DOWN UNLESS YOU FIX WHICH IS HARD
#if false floater will come. if true, PCModder version of floater will come
flashFloat = True
#new model for all bombs OP related to regular bomb model
spikeModel = False

defaultBoxingGloves = True

defaultShields = False

#this is where the character fun comes in. admin system is ver powerfull
rchar = False

wizard = False

pixie = False

ninja = False

frosty = False

pengu = False

ali = False

robot = False

santa = False

#this is where all the bomb fun comes in hehe
impact_bomb = False

ice_bomb = False

sticky_bomb = False

spike_bomb = False

shock_wave = False

spaz_bomb = False

knock_bomb = False

glue_bomb = False

#flash comes when punched i have it remained false
punchFlash = False

powIce = False

powSplint = False

powSlime = False

powSweat = False

grav = False

muteAll = False

nighty = False
##DO NOT CHANGE ORDER OF SETTINGS DO NOT ADD OR DELETE POWERUPS MAJOR ERRROR---> ADMIN SYS USELESS AND DOWN UNLESS YOU FIX WHICH IS HARD
#created fully by PC||231392 or PC||Modder, with no python knowledge
#enable true or false. by PCModder, thanks to the the great and for the discoLights
#the distance between you and success is fear.
#from here or add more settings if you liek but never from the top or big errors will pop
#also dont add any or delete any powerups or error will come, thank you
#All rights to PC||231392
#Thanks to God