import datetime
import bs

ownerPerk = False

muteAll = False

enableVerification = False

enableCoinSystem = True

questionDelay = 90 #60 #seconds
questionsList = {'Which virus is spreading currently?': 'corona', 'Which country Corona is originated?': 'china', 'Effiel Tower is located in which city?': 'paris', 'Largest Planet in our solar system?': 'jupiter',
       'add': None, 
       'multiply': None}

#all rights reserved to PCModder/Mikahael/PCModder as the license states.