adminHashes = []
vipHashes = []
banlist = {}
topperslist = []
effectCustomers = {}
customlist = {}
ownerHashes = ['pb-IF4VV1QaEw==']
surroundingObjectEffect = []
sparkEffect = []
smokeEffect = []
scorchEffect = [] 
distortionEffect = ['pb-IF4VV1QaEw==']
glowEffect = [] 
iceEffect=[]
slimeEffect = []
metalEffect = []
dragonHashes = []
customtagHashes=[]

#donot change the order of the list
#to enable/disable commands and effects for top 5 players goto settings.py

